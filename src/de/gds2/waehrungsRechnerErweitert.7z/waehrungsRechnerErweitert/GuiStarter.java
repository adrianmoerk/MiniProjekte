package de.gds2.waehrungsRechnerErweitert;

public class GuiStarter {
    public static void main(String[] args) {
        Gui gui = new Gui();
        gui.setVisible(true);
    }
}
