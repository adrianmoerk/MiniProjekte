package de.gds2.krappelCAD;

public class Material {
    public static final int soft = 1;
    public static final int hard = 2;
    public static final int dry = 3;
    public static final int wet = 4;
    public static final int smooth = 5;
    public static final int rough = 6;

    private Material(int soft, int hard, int dry, int wet, int smooth, int rough) {
    }
}
