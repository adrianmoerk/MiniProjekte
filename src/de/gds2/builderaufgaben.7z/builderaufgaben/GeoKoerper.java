package de.gds2.builderaufgaben;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class GeoKoerper {
    public GeoKoerper() {
        kugelberechnungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kugelberechnung();
            }
        });
        kreiszylinderberechnungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kreiszylinderberechnung();
            }
        });
        kreiskegelberechnungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kreiskegelberechnung();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("GeoKoerper");
        frame.setContentPane(new GeoKoerper().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel panel1;
    private JPanel Kugel;
    private JPanel Kreiszylinder;
    private JTextField radius;
    private JTextField volumen;
    private JTextField oberflaeche;
    private JButton kugelberechnungButton;
    private JTextField radiusR;
    private JTextField volumenR;
    private JTextField oberflaecheR;
    private JTextField mantelflaecheR;
    private JButton kreiszylinderberechnungButton;
    private JPanel Kreiskegel;
    private JTextField radiusKk;
    private JTextField Hoehekk;
    private JTextField volumenkk;
    private JTextField oberflaechekk;
    private JTextField mantelflaechekk;
    private JTextField HoeheKz;
    private JButton kreiskegelberechnungButton;

    //Kugel
    public void kugelberechnung() {
        DecimalFormat df = new DecimalFormat("#.00");
        double r = Double.parseDouble(this.radius.getText());
        double v = 4 / 3 * Math.PI * r * r * r;
        double o = 4 * Math.PI * r * r;
        volumen.setText(df.format(v));
        oberflaeche.setText(df.format(o));
    }

    //Kreiszylinder
    public void kreiszylinderberechnung() {
        DecimalFormat df = new DecimalFormat("#.00");
        double r = Double.parseDouble(this.radiusR.getText());
        double h = Double.parseDouble(this.HoeheKz.getText());
        double v = Math.PI * r * r * h;
        double o = 2 * Math.PI * r * (r + h);
        double m = 2 * Math.PI * r * r;
        volumenR.setText(df.format(v));
        oberflaecheR.setText(df.format(o));
        mantelflaecheR.setText(df.format(m));
    }

    //Kreiskegel
    public void kreiskegelberechnung() {
        DecimalFormat df = new DecimalFormat("#.00");
        double r = Double.parseDouble(this.radiusKk.getText());
        double h = Double.parseDouble(this.Hoehekk.getText());
        double v = Math.PI * r * r * h;
        double o = 2 * Math.PI * r * (r + h);
        double m = 2 * Math.PI * r * r;
        volumenkk.setText(df.format(v));
        oberflaechekk.setText(df.format(o));
        mantelflaechekk.setText(df.format(m));
    }
}
