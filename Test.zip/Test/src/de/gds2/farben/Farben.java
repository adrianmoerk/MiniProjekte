package de.gds2.farben;

public enum Farben {
    VIOLETT, SCHWARZ, BLAU, ROT;
}
