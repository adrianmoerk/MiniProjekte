package de.gds2.motorrad;

public class Motorrad {

}
